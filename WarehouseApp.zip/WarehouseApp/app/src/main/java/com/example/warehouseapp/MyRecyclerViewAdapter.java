package com.example.warehouseapp;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.warehouseapp.provider.WarehouseItem;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {

    List<WarehouseItem> itemData = new ArrayList<>();

    public MyRecyclerViewAdapter() { //instantiate the class
    }

    public void setItemData(List<WarehouseItem> itemData) {
        this.itemData = itemData;
    }

    @NonNull
    @Override
    public MyRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view, parent, false); //CardView inflated as RecyclerView list item
        ViewHolder viewHolder = new ViewHolder(v); //have to let app know inside got 3 details, will bind all the neccessay view component into the layoutn

        return viewHolder; //once return, it will be used as an input for the next callback
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerViewAdapter.ViewHolder holder, int position) {
        holder.itemID.setText(String.valueOf(itemData.get(position).getItemID()));
        holder.itemName.setText(itemData.get(position).getItemName());
        holder.itemQty.setText(itemData.get(position).getItemCost());
        holder.itemCost.setText(itemData.get(position).getItemQty());
        holder.itemDesc.setText(itemData.get(position).getItemDes());
        holder.itemFrozen.setText(itemData.get(position).getItemFroz());
        Log.d("week6App","onBindViewHolder");
    }

    @Override
    public int getItemCount() {
        return itemData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public View itemView;
        public TextView itemID;
        public TextView itemName;
        public TextView itemQty;
        public TextView itemCost;
        public TextView itemDesc;
        public TextView itemFrozen;


        public ViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            itemID = itemView.findViewById(R.id.cardID);
            itemName = itemView.findViewById(R.id.cardname);
            itemQty = itemView.findViewById(R.id.cardqty);
            itemCost = itemView.findViewById(R.id.cardcost);
            itemDesc = itemView.findViewById(R.id.carddesc);
            itemFrozen = itemView.findViewById(R.id.cardfroz);
        }
    }

}

